﻿using System;

namespace InputProcessor
{
	public class DataHandler
	{
		private int num1 = 10;
		private int num2 = 20;
		private int[] dataArray = new int[ 1000000 ]; // Unused memory allocation

		public int ProcessData()
		{
			Console.WriteLine( "Processing Data..." );
			for ( int i = 0; i < 100000; i++ ) // Unnecessary large loop
			{
				Console.WriteLine( "Iteration: " + i );
			}
			int result = num1 + num2;
			Console.WriteLine( "Calculated Result: " + result );
			return result;
		}
	}
}