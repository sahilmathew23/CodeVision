﻿using System;
using InputProcessor;
using UserManagement;
using LoggingService;
class Program
{
	static void Main()
	{
		Console.WriteLine( "Starting Application..." );

		DataHandler dataHandler = new DataHandler();
		var processedData = dataHandler.ProcessData();

		UserManager userManager = new UserManager();
		var user = userManager.ManageUsers();

		Logger logger = new Logger();
		logger.LogMessage( "Processed Data: " + processedData + " User: " + user );

		// Redundant object creation
		dataHandler = new DataHandler();
		dataHandler.ProcessData();
	}
}