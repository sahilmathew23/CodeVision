```csharp
using System;
using System.IO;
using Microsoft.Extensions.Logging; // Use built-in logging for extensibility

namespace LoggingService
{
    public interface ILoggerService // Interface for loose coupling and testability
    {
        void LogInformation(string message);
        void LogWarning(string message);
        void LogError(string message, Exception ex = null);
    }

    public class Logger : ILoggerService
    {
        private readonly ILogger<Logger> _logger; // Use ILogger interface

        public Logger(ILogger<Logger> logger) // Constructor injection for DI
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void LogInformation(string message)
        {
            _logger.LogInformation(message);
        }

        public void LogWarning(string message)
        {
            _logger.LogWarning(message);
        }

        public void LogError(string message, Exception ex = null)
        {
            if (ex == null)
            {
                _logger.LogError(message);
            }
            else
            {
                _logger.LogError(ex, message);
            }
        }

        //Example of extension method for more specific logging
        public static class LoggerExtensions
        {
            public static void LogCriticalEvent(this ILoggerService logger, string message)
            {
                logger.LogError($"CRITICAL EVENT: {message}");
            }
        }
    }
}
```

**Explanation of Modifications:**

1.  **SOLID Principles:**

    *   **Single Responsibility Principle (SRP):** The `Logger` class now *only* handles logging responsibilities.  It doesn't concern itself with file access, which the original did implicitly.  It relies on `ILogger` for the actual writing.
    *   **Open/Closed Principle (OCP):**  The `Logger` class is now open for extension (through the `ILogger` abstraction) but closed for modification. You can add new logging targets or functionalities without changing the `Logger` class itself. For example, the `LoggerExtensions` class demonstrates how to add custom logging methods without modifying the core `Logger` class.
    *   **Liskov Substitution Principle (LSP):**  Any class implementing `ILoggerService` can be used in place of the `Logger` class without breaking the application.
    *   **Interface Segregation Principle (ISP):** The `ILoggerService` interface provides a clear contract for logging, separating the responsibilities of different types of log messages (information, warning, error).  If different parts of the application only need to write certain types of logs, specialized interfaces could be created.
    *   **Dependency Inversion Principle (DIP):**  The `Logger` class depends on the abstraction `ILogger` (provided by Microsoft.Extensions.Logging) and `ILoggerService`, not concrete implementations. This makes the code more flexible and testable.

2.  **Modularity and Reusability:**

    *   **Interface `ILoggerService`:** Introduces an interface to decouple the logger implementation from the clients. This makes it easier to replace the logger with a different implementation (e.g., logging to a database, a message queue, or a different logging framework).  This enables a much more modular design.
    *   **Dependency Injection:**  The `Logger` class now uses constructor injection to receive an `ILogger<Logger>` instance. This allows the logging configuration (where logs are written, log levels, etc.) to be managed externally, typically through a dependency injection container. This is a critical aspect of making the code reusable in different environments.

3.  **Performance and Scalability:**

    *   **Using `ILogger`:** Leverages the `ILogger` interface from `Microsoft.Extensions.Logging`, which is designed for performance and scalability.  `ILogger` implementations often use asynchronous logging and buffering to minimize the impact on the application's performance. The original code's synchronous `StreamWriter` instantiation and disposal on every log entry would be a major performance bottleneck, especially under high load.
    *   **Avoid File Locking:** The original code's approach of opening and closing the file on every log message can lead to file locking issues and contention, particularly in multi-threaded environments. `ILogger` implementations handle this internally.

4.  **Error Handling and Logging:**

    *   **Exception Handling:** The `LogError` method now accepts an `Exception` object. This allows you to log detailed exception information along with the error message, which is crucial for debugging and troubleshooting. The use of `ex` in the logging context can contain stack traces, inner exceptions, and other diagnostic data.
    *   **Argument Validation:** The constructor checks for null `ILogger` and throws an `ArgumentNullException` if it's null, preventing potential null reference exceptions later on.
    *   **Logging Levels:** The code uses `LogInformation`, `LogWarning`, and `LogError` methods, providing a structured way to categorize log messages and control their verbosity.  The logging level configuration (e.g., in `appsettings.json`) determines which messages are actually written to the log.

5.  **Security Best Practices:**

    *   **Avoid Direct File Path Configuration:** The original code hardcoded the log file path.  By relying on `ILogger`, the log file path and other configuration settings are externalized and managed through the application's configuration system, which can be secured separately.  This also prevents hardcoding sensitive information.
    *   **Input Validation (Not Explicitly Shown):** While not directly implemented in this example, it's crucial to sanitize any input used in log messages to prevent log injection attacks.  `ILogger` implementations often have built-in protection against basic injection attempts, but thorough input validation is still necessary.

6.  **.NET Coding Conventions:**

    *   **Using Statements:** Using statements are used to ensure proper disposal of resources and avoid memory leaks (which the original code had).
    *   **PascalCase for Public Members:** Follows standard .NET naming conventions for classes, interfaces, and methods.
    *   **Readonly Fields:**  The `_logger` field is declared as `readonly`, indicating that it's only initialized in the constructor and cannot be changed later.
    *   **Null Checks:**  Added a null check in the constructor to prevent `NullReferenceException`.

**How to Use:**

1.  **Install NuGet Packages:**

    ```bash
    dotnet add package Microsoft.Extensions.Logging
    dotnet add package Microsoft.Extensions.Logging.Console # Or any other logger provider
    ```

2.  **Configure Logging:**

    In your `Program.cs` or startup code, configure the `ILogger` instance and inject it into your `Logger` class:

    ```csharp
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using LoggingService;

    public class Program
    {
        public static void Main(string[] args)
        {
            // Setup dependency injection
            var serviceProvider = new ServiceCollection()
                .AddLogging(builder =>
                {
                    builder.AddConsole(); // Example: Log to the console
                    builder.SetMinimumLevel(LogLevel.Information); // Set log level
                })
                .AddSingleton<ILoggerService, Logger>() // Register Logger
                .BuildServiceProvider();

            // Get the logger instance
            var loggerService = serviceProvider.GetService<ILoggerService>();

            // Use the logger
            loggerService.LogInformation("Application started");

            try
            {
                // Some code that might throw an exception
                throw new Exception("Something went wrong");
            }
            catch (Exception ex)
            {
                loggerService.LogError("An error occurred", ex);
            }

            loggerService.LogWarning("Application is about to finish");
            // Example of using extension method:
            loggerService.LogCriticalEvent("A critical event occurred!");
        }
    }
    ```

3.  **Inject `ILoggerService`:**  In any class where you need to log, inject the `ILoggerService` interface through the constructor.

**Benefits:**

*   **Testability:**  You can easily mock or stub the `ILoggerService` and `ILogger` interfaces in unit tests to verify that logging is happening correctly.
*   **Flexibility:** You can switch between different logging providers (e.g., Console, File, Database, Application Insights) without modifying the application's core code.
*   **Maintainability:** The code is more modular and easier to maintain.  Changes to the logging implementation won't require changes to the classes that use the logger.
*   **Performance:** Leveraging `Microsoft.Extensions.Logging` provides better performance and scalability compared to writing directly to a file.
*   **Configuration:** Logging configuration is externalized and can be managed through environment variables, configuration files, or other sources.

This enhanced version provides a more robust, flexible, and maintainable logging solution that adheres to SOLID principles and .NET best practices.  It addresses the shortcomings of the original code, making it suitable for use in larger, more complex applications.  Most importantly, it moves from a brittle, file-based logging implementation to a flexible and powerful framework-integrated approach.
