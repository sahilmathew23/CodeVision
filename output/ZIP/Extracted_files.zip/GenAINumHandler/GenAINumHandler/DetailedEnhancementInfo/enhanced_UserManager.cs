Below is an enhanced version of the `UserManager.cs` addressing the specified goals:

```csharp
using System;
using System.Collections.Generic;
using System.Linq;

namespace UserManagement
{
    public interface IUserManager
    {
        string GetUser(int index);
        IEnumerable<string> GetAllUsers();
    }

    public class UserManager : IUserManager
    {
        private readonly List<string> _users;

        public UserManager()
        {
            _users = new List<string> { "Alice", "Bob" };
        }

        public string GetUser(int index)
        {
            if (index < 0 || index >= _users.Count)
            {
                throw new ArgumentOutOfRangeException(nameof(index), "Index is out of bounds");
            }
            return _users[index];
        }

        public IEnumerable<string> GetAllUsers()
        {
            return _users.AsReadOnly();
        }
    }
}
```

### Explanation of Modifications

1. **Interface Implementation (Applying SOLID - Dependency Inversion Principle):**
   - An interface `IUserManager` is introduced to define the contract for user management. This approach facilitates easier substitution and integration, enhancing modularity and enabling better adherence to the Dependency Inversion Principle.

2. **Encapsulation and Data Hiding:**
   - The internal list `_users` is now a private field within `UserManager` to prevent external classes from modifying it directly, hence maintaining encapsulation.

3. **Improved Method Structure and Error Handling:**
   - Introduced `GetUser` method to retrieve a user at a specific index with thorough boundary checking and appropriate exception handling (`ArgumentOutOfRangeException`). This provides robust error management compared to the original indexing approach which would crash on out-of-bounds access.
   - Added `GetAllUsers` method to return all users as an immutable collection (`AsReadOnly`). This approach respects data encapsulation and minimizes the risk of unauthorized modifications to the internal `_users` list.

4. **Use of Readonly Collection to Ensure Data Integrity:**
   - The return type of `IEnumerable<string>` along with the use of `.AsReadOnly()` method ensures that caller of `GetAllUsers()` cannot modify the underlying collection. This addresses security concerning data tampering.

5. **Constructor for Initialization:**
   - The constructor initializes `_users` directly. This encapsulates the initial setup and allows for potential future enhancements such as fetching initial user data from an external data source.

6. **Adherence to .NET Coding Conventions:**
   - The code adheres to conventions such as PascalCase for methods and properties, exception management, and documentation comments that could be added to methods for further clarity.

By introducing these changes, the `UserManager` class has become more robust, modular, and easier to maintain, while also facilitating secure and efficient interactions with user data.