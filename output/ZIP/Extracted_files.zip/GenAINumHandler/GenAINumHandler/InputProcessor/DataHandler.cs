using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;

namespace InputProcessor
{
    public interface IDataProcessor
    {
        int ProcessData();
    }

    public class DataProcessorOptions
    {
        public int Num1 { get; set; } = 10;
        public int Num2 { get; set; } = 20;
        public int IterationCount { get; set; } = 1000; // Reduced from 100000 for efficiency
    }

    public class DataHandler : IDataProcessor
    {
        private readonly int _num1;
        private readonly int _num2;
        private readonly ILogger<DataHandler> _logger;
        private readonly int _iterationCount;

        public DataHandler(ILogger<DataHandler> logger, DataProcessorOptions options)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            if (options == null) throw new ArgumentNullException(nameof(options));

            _num1 = options.Num1;
            _num2 = options.Num2;
            _iterationCount = options.IterationCount;

            _logger.LogInformation("DataHandler initialized with Num1: {Num1}, Num2: {Num2}, IterationCount: {IterationCount}", _num1, _num2, _iterationCount);
        }

        public int ProcessData()
        {
            _logger.LogInformation("Starting data processing...");

            Stopwatch stopwatch = Stopwatch.StartNew();

            try
            {
                // Consider removing the loop completely if it has no business value.
                // If the loop is necessary, optimize or parallelize as needed.
                for (int i = 0; i < _iterationCount; i++)
                {
                    if (i % 100 == 0) // Log every 100 iterations
                    {
                        _logger.LogDebug("Iteration: {Iteration}", i);
                    }

                    // Simulate some operation inside the loop to prevent the compiler from optimizing it away.
                    // Remove if this is just a dummy loop for demonstration.
                    // Do not introduce unnecessary memory allocations inside the loop.

                }

                int result = _num1 + _num2;
                _logger.LogInformation("Calculated result: {Result}", result);

                stopwatch.Stop();
                _logger.LogInformation("Data processing completed in {ElapsedMilliseconds}ms", stopwatch.ElapsedMilliseconds);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during data processing.");
                throw; // Re-throw the exception to allow the caller to handle it.
            }
            finally
            {
                // Clean up resources if needed (e.g., closing database connections).
            }
        }
    }
}