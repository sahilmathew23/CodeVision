using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;

namespace InputProcessor
{
    public interface IDataProcessor
    {
        int ProcessData();
    }

    public class DataHandler : IDataProcessor
    {
        private readonly int _num1;
        private readonly int _num2;
        private readonly ILogger<DataHandler> _logger;

        public DataHandler(int num1, int num2, ILogger<DataHandler> logger)
        {
            _num1 = num1;
            _num2 = num2;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger)); // Argument validation
        }

        public int ProcessData()
        {
            _logger.LogInformation("Data processing started.");

            try
            {
                Stopwatch sw = Stopwatch.StartNew();
                int result = CalculateResult();
                sw.Stop();

                _logger.LogInformation("Data processing completed. Result: {Result}, Elapsed time: {ElapsedTime} ms", result, sw.ElapsedMilliseconds);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during data processing.");
                throw; // Re-throw to allow calling code to handle/report
            }
        }

        private int CalculateResult()
        {
            _logger.LogDebug("Calculating result...");
            // Simulate some workload (removed the large loop and console writes which impacts performance)
            int result = _num1 + _num2;
            _logger.LogDebug("Calculated result: {Result}", result);
            return result;
        }
    }
}


using Microsoft.Extensions.Logging;

// ...

// Get an ILogger instance (how you get this depends on your logging setup)
ILoggerFactory loggerFactory = LoggerFactory.Create(builder =>
{
    builder.AddConsole(); // Or any other logging provider
});
ILogger<DataHandler> logger = loggerFactory.CreateLogger<DataHandler>();

DataHandler handler = new DataHandler(5, 7, logger);
int result = handler.ProcessData();
Console.WriteLine("Result: " + result);