using System;
using Microsoft.Extensions.Logging;

namespace InputProcessor
{
    // Interface for data processing, adhering to the Interface Segregation Principle (ISP)
    public interface IDataProcessor
    {
        int ProcessData();
    }

    // Class responsible solely for addition operation, adhering to the Single Responsibility Principle (SRP)
    public class DataCalculator
    {
        private readonly ILogger<DataCalculator> _logger;

        public DataCalculator(ILogger<DataCalculator> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public int Add(int num1, int num2)
        {
            _logger.LogInformation("Adding {num1} and {num2}", num1, num2); // Using structured logging

            // Basic input validation to prevent unexpected behavior
            if (num1 < 0 || num2 < 0)
            {
                _logger.LogWarning("Negative numbers detected in Add operation.  Consider validating data sources.");
            }

            try
            {
                checked
                {
                    int result = num1 + num2;
                    _logger.LogInformation("Addition result: {result}", result);
                    return result;
                }
            }
            catch (OverflowException ex)
            {
                _logger.LogError(ex, "Overflow occurred during addition operation.");
                throw; // Re-throwing the exception after logging.  Caller can decide how to handle it.
            }

        }
    }

    //  DataHandler class implementing IDataProcessor, adhering to the Dependency Inversion Principle (DIP)
    public class DataHandler : IDataProcessor
    {
        private readonly int _num1;
        private readonly int _num2;
        private readonly DataCalculator _calculator;
        private readonly ILogger<DataHandler> _logger;


        public DataHandler(int num1, int num2, DataCalculator calculator, ILogger<DataHandler> logger)
        {
            _num1 = num1;
            _num2 = num2;
            _calculator = calculator ?? throw new ArgumentNullException(nameof(calculator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public int ProcessData()
        {
            _logger.LogInformation("Starting data processing.");

            // Removing the unnecessary loop. If the loop is necessary for initialization of something else it should be moved to initialization code in the constructor or a separate initialization method.
            // Also removed the console writes, logging using the interface instead

            try
            {
                int result = _calculator.Add(_num1, _num2);
                _logger.LogInformation("Data processing completed. Result: {result}", result);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during data processing.");
                throw; // Re-throwing the exception to allow the caller to handle it.
            }

        }
    }
}


using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using InputProcessor;

class Program
{
    static void Main(string[] args)
    {
        using IHost host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((_, services) =>
            {
                // Register logging
                services.AddLogging(builder =>
                {
                    builder.AddConsole(); // Example: Log to console
                    // Add other logging providers as needed (e.g., Serilog, Application Insights)
                });

                // Register DataCalculator and DataHandler
                services.AddSingleton<DataCalculator>();
                services.AddTransient<IDataProcessor>(provider =>
                {
                    var logger = provider.GetRequiredService<ILogger<DataHandler>>();
                    var calculator = provider.GetRequiredService<DataCalculator>();
                    return new DataHandler(5, 7, calculator, logger); // You can specify the numbers here.
                });

            })
            .Build();

        var dataProcessor = host.Services.GetRequiredService<IDataProcessor>();
        try
        {
            int result = dataProcessor.ProcessData();
            Console.WriteLine($"Final result: {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
    }
}