using System;

namespace InputProcessor
{
    public interface IDataHandler
    {
        void ProcessData();
    }

    public class DataHandler : IDataHandler
    {
        private readonly int num1 = 10;
        private readonly int num2 = 20;

        public void ProcessData()
        {
            LogMessage("Starting processing data...");
            LogMessage($"Result: {CalculateResult()}");
        }

        private int CalculateResult()
        {
            int result = num1 + num2;
            return result;
        }

        private void LogMessage(string message)
        {
            Console.WriteLine(message); // Consider further enhancements here like using a dedicated logging framework.
        }
    }
}