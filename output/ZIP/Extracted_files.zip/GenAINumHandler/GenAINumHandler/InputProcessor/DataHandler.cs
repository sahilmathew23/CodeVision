using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;

namespace InputProcessor
{
	public interface IDataProcessor
	{
		int ProcessData();
	}

	public class DataProcessor : IDataProcessor
	{
		private readonly int _num1;
		private readonly int _num2;
		private readonly ILogger<DataProcessor> _logger;

		public DataProcessor( int num1, int num2, ILogger<DataProcessor> logger )
		{
			_num1 = num1;
			_num2 = num2;
			_logger = logger ?? throw new ArgumentNullException( nameof( logger ) ); // Guard clause
		}

		public int ProcessData()
		{
			_logger.LogInformation( "Starting data processing..." );
			var stopwatch = Stopwatch.StartNew();

			try
			{
				// Removing the unnecessary loop for performance.  Real-world logic would go here.
				// Simulate some processing:
				// Some calculation or data manipulation would occur here based on requirements
				// Example (replace with actual logic):
				// int intermediateResult = _num1 * _num2;

				int result = _num1 + _num2;

				_logger.LogInformation( "Calculated result: {Result}", result );
				stopwatch.Stop();
				_logger.LogInformation( "Data processing completed in {ElapsedMilliseconds}ms", stopwatch.ElapsedMilliseconds );
				return result;
			}
			catch ( Exception ex )
			{
				_logger.LogError( ex, "An error occurred during data processing." );
				throw; // Re-throw to allow the calling code to handle the exception further.
			}
		}
	}
}


using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

public class Program
{
    public static void Main(string[] args)
    {
        // Setup Dependency Injection
        var serviceProvider = new ServiceCollection()
            .AddLogging(builder => builder.AddConsole()) // Or another logging provider
            .AddTransient<IDataProcessor>(provider => new DataProcessor(15, 25, provider.GetRequiredService<ILogger<DataProcessor>>()))
            .BuildServiceProvider();

        // Resolve DataProcessor
        var dataProcessor = serviceProvider.GetRequiredService<IDataProcessor>();

        // Process Data
        try
        {
            int result = dataProcessor.ProcessData();
            Console.WriteLine($"Final Result: {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }

        Console.ReadKey();
    }
}