using System;
using Microsoft.Extensions.DependencyInjection;
using InputProcessor;
using UserManagement;
using LoggingService;
using System.Threading.Tasks;

namespace MyApplication
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Starting Application...");

            // Configure Dependency Injection
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IDataHandler, DataHandler>()
                .AddSingleton<IUserManager, UserManager>()
                .AddSingleton<ILogger, Logger>()
                .BuildServiceProvider();

            // Resolve dependencies
            var dataHandler = serviceProvider.GetService<IDataHandler>();
            var userManager = serviceProvider.GetService<IUserManager>();
            var logger = serviceProvider.GetService<ILogger>();

            try
            {
                // Process Data asynchronously
                var processedData = await Task.Run(() => dataHandler.ProcessData());

                // Manage Users asynchronously
                var user = await Task.Run(() => userManager.ManageUsers());

                // Log the results
                logger.LogMessage($"Processed Data: {processedData}, User: {user}");
            }
            catch (Exception ex)
            {
                // Centralized error handling
                logger.LogError($"An error occurred: {ex.Message}, Stack Trace: {ex.StackTrace}");
                Console.Error.WriteLine($"Application Error: {ex.Message}. See logs for details.");
            }
            finally
            {
                Console.WriteLine("Application Finished.");
            }
        }
    }

	// Define interfaces for Dependency Inversion
    public interface IDataHandler
    {
        string ProcessData();
    }

    public interface IUserManager
    {
        string ManageUsers();
    }

    public interface ILogger
    {
        void LogMessage(string message);
        void LogError(string message); //added for exception handling
    }
}