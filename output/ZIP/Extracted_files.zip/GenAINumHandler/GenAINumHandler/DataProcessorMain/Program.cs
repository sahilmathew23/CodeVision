using System;
using Microsoft.Extensions.DependencyInjection;
using InputProcessor;
using UserManagement;
using LoggingService;
using ConfigurationService; // Assuming a ConfigurationService exists

namespace MyApplication
{
    class Program
    {
        static void Main()
        {
            // Configure Dependency Injection
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IConfigurationService, DefaultConfigurationService>() // Replace with your concrete implementation
                .AddTransient<IDataProcessor, DataHandler>() // Transient because a new instance is needed per scope
                .AddTransient<IUserManager, UserManager>()
                .AddSingleton<ILogger, Logger>() //Singleton logger
                .BuildServiceProvider();


            // Resolve dependencies
            var logger = serviceProvider.GetService<ILogger>();
            var dataProcessor = serviceProvider.GetService<IDataProcessor>();
            var userManager = serviceProvider.GetService<IUserManager>();
            var configurationService = serviceProvider.GetService<IConfigurationService>();

            try
            {
                logger.LogMessage("Application starting...");

                // Configuration example
                string setting = configurationService.GetSetting("ImportantSetting");
                logger.LogMessage($"Important Setting: {setting}");


                // Process Data
                var processedData = dataProcessor.ProcessData();
                logger.LogMessage($"Processed Data: {processedData}");

                // Manage User
                var user = userManager.ManageUsers();
                logger.LogMessage($"User: {user}");

                logger.LogMessage("Application completed successfully.");
            }
            catch (Exception ex)
            {
                logger.LogError($"An error occurred: {ex.Message}", ex);
                Console.Error.WriteLine($"An unhandled error occurred.  See logs for details.");
            }
            finally
            {
                // Optionally, perform cleanup or shutdown tasks here
                Console.WriteLine("Application exiting.");
            }
        }
    }
}


// ConfigurationService/IConfigurationService.cs
namespace ConfigurationService
{
    public interface IConfigurationService
    {
        string GetSetting(string key);
    }
}

// ConfigurationService/DefaultConfigurationService.cs
namespace ConfigurationService
{
    public class DefaultConfigurationService : IConfigurationService
    {
        public string GetSetting(string key)
        {
            // In a real application, you would read from a configuration file or environment variable.
            if (key == "ImportantSetting")
            {
                return "Default Value";
            }
            return null;
        }
    }
}

// InputProcessor/IDataProcessor.cs
namespace InputProcessor
{
    public interface IDataProcessor
    {
        string ProcessData();
    }
}

// InputProcessor/DataHandler.cs
namespace InputProcessor
{
    public class DataHandler : IDataProcessor
    {
        public string ProcessData()
        {
            return "Processed Data";
        }
    }
}

// UserManagement/IUserManager.cs
namespace UserManagement
{
    public interface IUserManager
    {
        string ManageUsers();
    }
}

// UserManagement/UserManager.cs
namespace UserManagement
{
    public class UserManager : IUserManager
    {
        public string ManageUsers()
        {
            return "User Data";
        }
    }
}

// LoggingService/ILogger.cs
namespace LoggingService
{
    public interface ILogger
    {
        void LogMessage(string message);
        void LogError(string message, Exception ex);
    }
}

// LoggingService/Logger.cs
namespace LoggingService
{
    public class Logger : ILogger
    {
        public void LogMessage(string message)
        {
            Console.WriteLine($"[INFO] {message}");
        }

        public void LogError(string message, Exception ex)
        {
            Console.Error.WriteLine($"[ERROR] {message}: {ex.Message}");
            Console.Error.WriteLine(ex.StackTrace);  // Important for debugging
        }
    }
}