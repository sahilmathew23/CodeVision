using System;
using InputProcessor;
using UserManagement;
using LoggingService;

class Program
{
	static void Main()
	{
		try
		{
			Console.WriteLine("Starting Application...");

			var dataHandler = GetDataHandler();
			var processedData = dataHandler.ProcessData();

			var userManager = GetUserManager();
			var user = userManager.ManageUsers();

			var logger = GetLogger();
			logger.LogMessage($"Processed Data: {processedData} User: {user}");
		}
		catch (Exception ex)
		{
			Console.WriteLine("An error occurred. Please contact the admin.");
			GetLogger().LogError("Error in Main: " + ex.Message);
		}
	}

	private static IDataHandler GetDataHandler() => new DataHandler();
	private static IUserManager GetUserManager() => new UserManager();
	private static ILogger GetLogger() => new Logger();
}