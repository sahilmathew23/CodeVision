// Program.cs

using System;
using Microsoft.Extensions.DependencyInjection;
using InputProcessor;
using UserManagement;
using LoggingService;
using System.Threading.Tasks;

namespace MyApplication
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Starting Application...");

            // Setup dependency injection
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IDataHandler, DataHandler>()
                .AddSingleton<IUserManager, UserManager>()
                .AddSingleton<ILogger, Logger>()
                .BuildServiceProvider();

            // Resolve dependencies
            var dataHandler = serviceProvider.GetService<IDataHandler>();
            var userManager = serviceProvider.GetService<IUserManager>();
            var logger = serviceProvider.GetService<ILogger>();

            try
            {
                // Process data asynchronously
                var processedData = await dataHandler.ProcessDataAsync();

                // Manage users asynchronously
                var user = await userManager.ManageUsersAsync();

                // Log the results
                logger.LogInformation($"Processed Data: {processedData}, User: {user}");
            }
            catch (Exception ex)
            {
                logger.LogError($"An error occurred: {ex.Message}, Stack Trace: {ex.StackTrace}");
                Console.WriteLine($"An error occurred.  Check the logs for details.");
            }
            finally
            {
                Console.WriteLine("Application finished.");
            }
        }
    }
}


// IDataHandler.cs
namespace InputProcessor
{
    public interface IDataHandler
    {
        Task<string> ProcessDataAsync(); // Changed to async
    }
}

// IUserManager.cs
namespace UserManagement
{
    public interface IUserManager
    {
        Task<string> ManageUsersAsync(); // Changed to async
    }
}

// ILogger.cs
namespace LoggingService
{
    public interface ILogger
    {
        void LogInformation(string message);
        void LogError(string message);
    }
}