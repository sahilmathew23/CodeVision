using System;
using System.IO;
using System.Threading.Tasks;

namespace LoggingService
{
    public interface ILogger
    {
        Task LogMessageAsync(string message);
    }

    public class Logger : ILogger
    {
        private readonly string _filePath;

        public Logger(string filePath = "log.txt")
        {
            _filePath = filePath;
        }

        public async Task LogMessageAsync(string message)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(_filePath, true))
                {
                    await writer.WriteLineAsync($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} Logging started...");
                    await writer.WriteLineAsync(message);
                }
            }
            catch (Exception ex)
            {
                // Consider logging the exception to an alternative storage or notifying an administrator
                Console.Error.WriteLine($"Failed to log message. Error: {ex.Message}");
                throw; // Re-throwing the exception to be handled or logged elsewhere
            }
        }
    }
}