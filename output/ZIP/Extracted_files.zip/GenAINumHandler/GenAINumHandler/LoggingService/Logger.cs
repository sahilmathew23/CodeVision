using System;
using System.IO;

namespace LoggingService
{
    // Define an interface for logging
    public interface ILogger
    {
        void Log(string message);
    }

    // Implement a basic file logger
    public class FileLogger : ILogger
    {
        private readonly string _logFilePath;

        public FileLogger(string logFilePath = "log.txt")
        {
            _logFilePath = logFilePath;
        }

        public void Log(string message)
        {
            try
            {
                // Use 'using' statement to ensure the StreamWriter is properly disposed of
                using (StreamWriter writer = new StreamWriter(_logFilePath, true)) // Append to the file instead of overwriting
                {
                    writer.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}");
                }
            }
            catch (Exception ex)
            {
                // Log the exception to the console or another logger for debugging
                Console.Error.WriteLine($"Error writing to log file: {ex.Message}");
            }
        }
    }

    //Implement Console Logger for flexibility
    public class ConsoleLogger : ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}");
        }
    }

    // Implement a composite logger to log to multiple targets
    public class CompositeLogger : ILogger
    {
        private readonly ILogger[] _loggers;

        public CompositeLogger(params ILogger[] loggers)
        {
            _loggers = loggers;
        }

        public void Log(string message)
        {
            foreach (var logger in _loggers)
            {
                logger.Log(message);
            }
        }
    }

    // Factory pattern for creating loggers
    public static class LoggerFactory
    {
        public static ILogger GetLogger(LoggerType loggerType, string logFilePath = "log.txt")
        {
            switch (loggerType)
            {
                case LoggerType.File:
                    return new FileLogger(logFilePath);
                case LoggerType.Console:
                    return new ConsoleLogger();
                case LoggerType.Composite:
                    return new CompositeLogger(new FileLogger(logFilePath), new ConsoleLogger()); // Example composite
                default:
                    throw new ArgumentException("Invalid logger type specified.");
            }
        }
    }

    public enum LoggerType
    {
        File,
        Console,
        Composite
    }
}


using LoggingService;

public class MyApplication
{
    public void DoSomething()
    {
        // Get a file logger
        ILogger fileLogger = LoggerFactory.GetLogger(LoggerType.File, "my_application.log");
        fileLogger.Log("Application started.");

        // Get a console logger
        ILogger consoleLogger = LoggerFactory.GetLogger(LoggerType.Console);
        consoleLogger.Log("Doing some operation...");

        // Get a composite logger
        ILogger compositeLogger = LoggerFactory.GetLogger(LoggerType.Composite, "my_application.log");
        compositeLogger.Log("Operation complete.");
    }
}