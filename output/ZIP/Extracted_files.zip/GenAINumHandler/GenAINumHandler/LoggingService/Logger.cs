using System;
using System.IO;
using Microsoft.Extensions.Logging;

namespace LoggingService
{
    public interface ILoggerService
    {
        void LogInformation(string message);
        void LogWarning(string message);
        LogError(string message, Exception ex = null);
    }

    public class Logger : ILoggerService
    {
        private readonly string _logFilePath;
        private readonly ILogger<Logger> _logger; // Use built-in ILogger for structured logging

        public Logger(string logFilePath, ILogger<Logger> logger)
        {
            _logFilePath = logFilePath ?? throw new ArgumentNullException(nameof(logFilePath)); // Validate input
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void LogInformation(string message)
        {
            Log(LogLevel.Information, message);
            _logger.LogInformation(message); //Structured logging
        }

        public void LogWarning(string message)
        {
            Log(LogLevel.Warning, message);
            _logger.LogWarning(message); //Structured logging
        }

        public void LogError(string message, Exception ex = null)
        {
            Log(LogLevel.Error, message);
            _logger.LogError(ex, message); //Structured logging with Exception
        }


        private void Log(LogLevel logLevel, string message)
        {
            try
            {
                // Use Append for better performance and to avoid overwriting the log file.
                using (StreamWriter writer = File.AppendText(_logFilePath)) //Using ensures proper disposal
                {
                    writer.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{logLevel}] {message}");
                }
            }
            catch (Exception ex)
            {
                // Handle logging errors gracefully.  Log to console as fallback if file logging fails.
                Console.Error.WriteLine($"Error writing to log file: {ex.Message}");
                Console.Error.WriteLine($"Original message: {message}");

                //Consider using a secondary logging mechanism here. For example, writing errors to the Windows Event Log.
            }
        }
    }
}


using Microsoft.Extensions.Logging;

// ...

// In your startup code or dependency injection container:
string logFilePath = "application.log"; // Configure this from settings
ILoggerFactory loggerFactory = LoggerFactory.Create(builder =>
{
   builder.AddConsole();  //Output to console
   builder.AddDebug();   //Output to debug window
});
ILogger<Logger> loggerImplementation = loggerFactory.CreateLogger<Logger>();
ILoggerService logger = new Logger(logFilePath, loggerImplementation);


// ...

try
{
    // Some code that might throw an exception
}
catch (Exception ex)
{
    logger.LogError("An error occurred while processing...", ex);
}

logger.LogInformation("Application started successfully.");
logger.LogWarning("Disk space is running low.");