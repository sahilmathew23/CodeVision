using System;
using System.IO;

namespace LoggingService
{
    // Interface for logging, enabling different implementations.
    public interface ILogger
    {
        void Log(string message, LogLevel level = LogLevel.Information);
    }

    // Enum to represent different log levels.
    public enum LogLevel
    {
        Debug,
        Information,
        Warning,
        Error,
        Fatal
    }

    // Abstract class providing a base for different logger implementations.
    public abstract class LoggerBase : ILogger
    {
        protected readonly string _logFilePath;

        protected LoggerBase(string logFilePath)
        {
            _logFilePath = logFilePath ?? throw new ArgumentNullException(nameof(logFilePath), "Log file path cannot be null.");
        }

        public abstract void Log(string message, LogLevel level = LogLevel.Information);

        // Helper method to write to the log file, handling resource disposal.
        protected void WriteToLogFile(string message)
        {
            try
            {
                // Using statement ensures the StreamWriter is properly disposed of.
                using (StreamWriter writer = new StreamWriter(_logFilePath, true)) // Append mode
                {
                    writer.WriteLine(message);
                }
            }
            catch (Exception ex)
            {
                // Log the error if writing to the file fails.  This avoids infinite loops.
                //  A more robust solution might use a separate error logging mechanism (e.g., Event Log).
                Console.Error.WriteLine($"Error writing to log file: {ex.Message}");
            }
        }
    }


    // Concrete logger class that writes to a text file.
    public class FileLogger : LoggerBase
    {
        public FileLogger(string logFilePath) : base(logFilePath) { }

        public override void Log(string message, LogLevel level = LogLevel.Information)
        {
            string logMessage = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{level}] {message}";
            WriteToLogFile(logMessage);
        }
    }

    // Example of another Logger implementation (Console Logger)
    public class ConsoleLogger : ILogger
    {
        public void Log(string message, LogLevel level = LogLevel.Information)
        {
            Console.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{level}] {message}");
        }
    }

	// Example of another Logger implementation (Debug Logger)
    public class DebugLogger : ILogger
    {
        public void Log(string message, LogLevel level = LogLevel.Information)
        {
            System.Diagnostics.Debug.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{level}] {message}");
        }
    }
}


// Example Usage (Illustrative - would reside in a different part of the application)
using LoggingService;

public class ExampleUsage
{
    public void DoSomething(ILogger logger)
    {
        try
        {
            // Perform some operation
            logger.Log("Starting operation.", LogLevel.Information);
            // ... potentially failing operations
            throw new Exception("Something went wrong!");
        }
        catch (Exception ex)
        {
            logger.Log($"An error occurred: {ex.Message}", LogLevel.Error);
        }
        finally
        {
            logger.Log("Operation finished.", LogLevel.Information);
        }
    }

    public static void Main(string[] args)
    {
        // Example usage with FileLogger
        ILogger fileLogger = new FileLogger("application.log");
        ExampleUsage example = new ExampleUsage();
        example.DoSomething(fileLogger);

        // Example usage with ConsoleLogger
        ILogger consoleLogger = new ConsoleLogger();
        example.DoSomething(consoleLogger);

		// Example usage with DebugLogger
        ILogger debugLogger = new DebugLogger();
        example.DoSomething(debugLogger);
    }
}