using System;
using System.IO;
using Microsoft.Extensions.Logging; // Use built-in logging for extensibility

namespace LoggingService
{
    public interface ILoggerService // Interface for loose coupling and testability
    {
        void LogInformation(string message);
        void LogWarning(string message);
        void LogError(string message, Exception ex = null);
    }

    public class Logger : ILoggerService
    {
        private readonly ILogger<Logger> _logger; // Use ILogger interface

        public Logger(ILogger<Logger> logger) // Constructor injection for DI
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void LogInformation(string message)
        {
            _logger.LogInformation(message);
        }

        public void LogWarning(string message)
        {
            _logger.LogWarning(message);
        }

        public void LogError(string message, Exception ex = null)
        {
            if (ex == null)
            {
                _logger.LogError(message);
            }
            else
            {
                _logger.LogError(ex, message);
            }
        }

        //Example of extension method for more specific logging
        public static class LoggerExtensions
        {
            public static void LogCriticalEvent(this ILoggerService logger, string message)
            {
                logger.LogError($"CRITICAL EVENT: {message}");
            }
        }
    }
}


    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using LoggingService;

    public class Program
    {
        public static void Main(string[] args)
        {
            // Setup dependency injection
            var serviceProvider = new ServiceCollection()
                .AddLogging(builder =>
                {
                    builder.AddConsole(); // Example: Log to the console
                    builder.SetMinimumLevel(LogLevel.Information); // Set log level
                })
                .AddSingleton<ILoggerService, Logger>() // Register Logger
                .BuildServiceProvider();

            // Get the logger instance
            var loggerService = serviceProvider.GetService<ILoggerService>();

            // Use the logger
            loggerService.LogInformation("Application started");

            try
            {
                // Some code that might throw an exception
                throw new Exception("Something went wrong");
            }
            catch (Exception ex)
            {
                loggerService.LogError("An error occurred", ex);
            }

            loggerService.LogWarning("Application is about to finish");
            // Example of using extension method:
            loggerService.LogCriticalEvent("A critical event occurred!");
        }
    }