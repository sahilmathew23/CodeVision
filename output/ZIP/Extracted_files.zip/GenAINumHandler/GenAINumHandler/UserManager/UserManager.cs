using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace UserManagement
{
    public interface IUserRepository
    {
        IEnumerable<string> GetUsernames();
    }

    public class UserRepository : IUserRepository
    {
        // In a real application, this would access a database or other persistent storage
        private readonly List<string> _users = new List<string> { "Alice", "Bob" };

        public IEnumerable<string> GetUsernames()
        {
            return _users;
        }
    }


    public interface IUserManager
    {
        Result<List<string>> GetActiveUsers();
        Result<bool> AddUser(string username, string password);
    }

    public class UserManager : IUserManager
    {
        private readonly IUserRepository _userRepository;
        private readonly ILogger<UserManager> _logger;

        public UserManager(IUserRepository userRepository, ILogger<UserManager> logger)
        {
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }


        public Result<List<string>> GetActiveUsers()
        {
            try
            {
                var users = _userRepository.GetUsernames().ToList();
                _logger.LogInformation("Successfully retrieved users.");
                return Result<List<string>>.Success(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving users.");
                return Result<List<string>>.Failure("Failed to retrieve users.");
            }
        }


        public Result<bool> AddUser(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                _logger.LogWarning("Invalid username or password provided.");
                return Result<bool>.Failure("Username and password cannot be empty.");
            }

            try
            {
                // Simulate adding a user (in a real application, this would involve database interaction and password hashing)
                // In a real scenario, password hashing (e.g., using BCrypt) would be crucial.
                string hashedPassword = HashPassword(password); //Important: Replace this with a secure hashing algorithm
                _logger.LogInformation($"User {username} added successfully. Password hashed.");
                return Result<bool>.Success(true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error adding user {username}.");
                return Result<bool>.Failure($"Failed to add user {username}.");
            }
        }

        private string HashPassword(string password)
        {
            // **IMPORTANT SECURITY WARNING:**  This is a placeholder.  DO NOT USE THIS IN PRODUCTION.
            // Use a proper password hashing algorithm like BCrypt, Argon2, or PBKDF2.
            //  This example uses a weak hash algorithm (SHA256) solely for demonstration purposes and is **INSECURE**.

            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));

                // Convert byte array to a string
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

    }

    public class Result<T>
    {
        public bool IsSuccess { get; private set; }
        public T? Value { get; private set; }
        public string? ErrorMessage { get; private set; }

        private Result(bool isSuccess, T? value, string? errorMessage)
        {
            IsSuccess = isSuccess;
            Value = value;
            ErrorMessage = errorMessage;
        }

        public static Result<T> Success(T value)
        {
            return new Result<T>(true, value, null);
        }

        public static Result<T> Failure(string errorMessage)
        {
            return new Result<T>(false, default, errorMessage);
        }
    }
}


using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using UserManagement;

var services = new ServiceCollection();

// Add logging
services.AddLogging(builder =>
{
    builder.AddConsole(); // Or any other logging provider
});

// Register dependencies
services.AddScoped<IUserRepository, UserRepository>();
services.AddScoped<IUserManager, UserManager>();


var serviceProvider = services.BuildServiceProvider();

// Get an instance of UserManager
var userManager = serviceProvider.GetService<IUserManager>();

// Use the UserManager
var result = userManager.GetActiveUsers();

if (result.IsSuccess)
{
    Console.WriteLine("Users: " + string.Join(", ", result.Value!));
}
else
{
    Console.WriteLine("Error: " + result.ErrorMessage);
}

var addResult = userManager.AddUser("NewUser", "P@$$wOrd");

if(addResult.IsSuccess)
{
    Console.WriteLine("User added successfully.");
}
else
{
    Console.WriteLine($"Failed to add user: {addResult.ErrorMessage}");
}