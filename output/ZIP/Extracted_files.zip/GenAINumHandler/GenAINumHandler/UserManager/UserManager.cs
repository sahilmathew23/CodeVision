using System;
using System.Collections.Generic;

namespace UserManagement
{
    public interface IUserManager
    {
        string GetUserByIndex(int index);
        List<string> GetAllUsers();
    }

    public class UserManager : IUserManager
    {
        private readonly List<string> _users;
        
        public UserManager()
        {
            _users = new List<string> { "Alice", "Bob" };
        }

        public string GetUserByIndex(int index)
        {
            if (index < 0 || index >= _users.Count)
            {
                // Log error: Index is out of the range
                Console.Error.WriteLine($"Error: Attempted to access an invalid user index {index}.");
                return null; // Alternatively, throw a custom exception or handle as per business need
            }

            return _users[index];
        }

        public List<string> GetAllUsers()
        {
            return new List<string>(_users); // Return a copy for encapsulation
        }
    }
}