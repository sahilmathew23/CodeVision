using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace UserManagement
{
    // Interface for user repository.  Abstraction to the data access layer.
    public interface IUserRepository
    {
        Task<List<string>> GetUserNamesAsync();
    }

    // Concrete implementation of UserRepository.  Separation of concerns.
    public class UserRepository : IUserRepository
    {
        // In a real-world scenario, this would connect to a database.  For simplicity, it's hardcoded.
        public async Task<List<string>> GetUserNamesAsync()
        {
            // Simulate a database call with a small delay.
            await Task.Delay(100);
            return new List<string> { "Alice", "Bob", "Charlie" };
        }
    }

    // Interface for password hashing.  Supports multiple hashing algorithms in the future.
    public interface IPasswordHasher
    {
        string HashPassword(string password, byte[] salt);
        bool VerifyPassword(string password, string hashedPassword, byte[] salt);
        byte[] GenerateSalt();
    }

    // Concrete implementation of PasswordHasher.  Uses SHA256 for hashing.
    public class PasswordHasher : IPasswordHasher
    {
        public string HashPassword(string password, byte[] salt)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] saltedPassword = salt.Concat(passwordBytes).ToArray(); // Salt the password
                byte[] hashBytes = sha256.ComputeHash(saltedPassword);
                return Convert.ToBase64String(hashBytes);
            }
        }

        public bool VerifyPassword(string password, string hashedPassword, byte[] salt)
        {
            string newHashedPassword = HashPassword(password, salt);
            return hashedPassword == newHashedPassword;
        }

        public byte[] GenerateSalt()
        {
            byte[] salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }
            return salt;
        }
    }



    public interface IUserManager
    {
        Task<List<string>> GetActiveUserNamesAsync();
        string CreateUser(string username, string password); // Simplified for demonstration
    }


    public class UserManager : IUserManager
    {
        private readonly IUserRepository _userRepository;
        private readonly ILogger<UserManager> _logger;
        private readonly IPasswordHasher _passwordHasher;

        // Constructor injection for dependencies.
        public UserManager(IUserRepository userRepository, ILogger<UserManager> logger, IPasswordHasher passwordHasher)
        {
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _passwordHasher = passwordHasher ?? throw new ArgumentNullException(nameof(passwordHasher));
        }


        // Improved method to manage users, leveraging the repository.
        public async Task<List<string>> GetActiveUserNamesAsync()
        {
            try
            {
                var userNames = await _userRepository.GetUserNamesAsync();
                // Add business logic, e.g., filtering active users.  For this example, return all.
                _logger.LogInformation("Successfully retrieved user names.");
                return userNames;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user names.");
                // Re-throw or handle the exception as needed.  Consider custom exceptions.
                throw;
            }
        }

        public string CreateUser(string username, string password)
        {
            try
            {
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    throw new ArgumentException("Username and password cannot be empty.");
                }

                // Generate a salt for each user
                byte[] salt = _passwordHasher.GenerateSalt();

                // Hash the password using the generated salt
                string hashedPassword = _passwordHasher.HashPassword(password, salt);

                // Log the user creation (in a real application, this would involve storing the username,
                // hashed password, and salt securely in a database)
                _logger.LogInformation($"User '{username}' created successfully (hashed password stored).");

                // Return a success message
                return $"User '{username}' created successfully.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error creating user '{username}'.");
                return $"Error creating user: {ex.Message}";
            }
        }
    }
}


// Example usage (Console Application Program.cs)
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using UserManagement;

public class Program
{
    public static async Task Main(string[] args)
    {
        // Setup dependency injection
        var serviceProvider = new ServiceCollection()
            .AddLogging(builder =>
            {
                builder.AddConsole(); // Logs to the console
                builder.SetMinimumLevel(LogLevel.Information); // Log level
            })
            .AddSingleton<IUserRepository, UserRepository>()
            .AddSingleton<IPasswordHasher, PasswordHasher>()
            .AddSingleton<IUserManager, UserManager>()
            .BuildServiceProvider();

        // Resolve dependencies
        var userManager = serviceProvider.GetService<IUserManager>();
        var logger = serviceProvider.GetService<ILogger<Program>>();

        try
        {
            if (userManager != null)
            {
                var userNames = await userManager.GetActiveUserNamesAsync();
                Console.WriteLine("User Names:");
                foreach (var userName in userNames)
                {
                    Console.WriteLine($"- {userName}");
                }

                string createUserResult = userManager.CreateUser("TestUser", "P@$$wOrd");
                Console.WriteLine(createUserResult);
            }
            else
            {
                Console.WriteLine("UserManager is null.");
            }
        }
        catch (Exception ex)
        {
            logger?.LogError(ex, "An error occurred in the application.");  // Use null-conditional operator
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
    }
}