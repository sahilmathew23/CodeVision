using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace UserManagement
{
    // Interface for user management operations (Interface Segregation Principle & Dependency Inversion Principle)
    public interface IUserManager
    {
        IEnumerable<string> GetUsers();
    }

    // Class responsible for retrieving users from a data source (Single Responsibility Principle & Open/Closed Principle)
    public class UserManager : IUserManager
    {
        private readonly IUserRepository _userRepository;
        private readonly ILogger<UserManager> _logger;

        // Dependency Injection to allow flexibility and testability (Dependency Inversion Principle)
        public UserManager(IUserRepository userRepository, ILogger<UserManager> logger)
        {
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        // Retrieves the users from the injected repository.
        public IEnumerable<string> GetUsers()
        {
            try
            {
                var users = _userRepository.GetUsers();
                _logger.LogInformation("Successfully retrieved users.");
                return users;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving users.");
                // Re-throw or handle the exception depending on the application's needs.
                throw; // Re-throwing to allow the caller to handle.  Consider a custom exception for specific error reporting.
            }
        }


        //This method is removed, as the original class had an obvious error and the logic
        //is better placed within the UserRepository

        //public string ManageUsers()
        //{
        //  string[] users = { "Alice", "Bob" };
        //  return users[ 5 ]; // Index out of bounds, no error handling
        //}
    }

    // Abstraction for user data access (Dependency Inversion Principle)
    public interface IUserRepository
    {
        IEnumerable<string> GetUsers();
    }

    // Concrete implementation for accessing user data from a static source (Open/Closed Principle)
    public class StaticUserRepository : IUserRepository
    {
        public IEnumerable<string> GetUsers()
        {
            //Static array simulating a database
            string[] users = { "Alice", "Bob" };
            return users.ToList();
        }
    }
}


    // Example in ASP.NET Core
    public class MyController : ControllerBase
    {
        private readonly IUserManager _userManager;

        public MyController(IUserManager userManager)
        {
            _userManager = userManager;
        }

        [HttpGet("/users")]
        public IActionResult GetUsers()
        {
            try
            {
                var users = _userManager.GetUsers();
                return Ok(users);
            }
            catch (Exception ex)
            {
                // Handle exception appropriately (e.g., return a 500 error).
                return StatusCode(500, "An error occurred while retrieving users.");
            }
        }
    }