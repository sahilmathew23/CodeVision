using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

namespace UserManagement
{
    // Interface defining the contract for user management operations
    public interface IUserManager
    {
        IEnumerable<string> GetUsers();
        string? GetUser(int index);
        bool AddUser(string username);
        bool RemoveUser(string username);
    }

    // Concrete implementation of the UserManager
    public class UserManager : IUserManager
    {
        private readonly ILogger<UserManager> _logger;
        private readonly List<string> _users; // Use a List for dynamic user management

        // Constructor injection for logging and dependency on a user repository (if needed)
        public UserManager(ILogger<UserManager> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _users = new List<string>() { "Alice", "Bob" }; // Initialize users. Could come from DB.
        }

        // Get all users
        public IEnumerable<string> GetUsers()
        {
            _logger.LogInformation("Getting all users.");
            return _users.AsReadOnly(); // Return as read-only to prevent external modification.
        }


        // Retrieve a user by index, with proper error handling
        public string? GetUser(int index)
        {
            _logger.LogInformation("Attempting to get user at index: {Index}", index);
            if (index >= 0 && index < _users.Count)
            {
                _logger.LogDebug("User found at index: {Index}", index);
                return _users[index];
            }
            else
            {
                _logger.LogError("Index out of bounds: {Index}", index);
                return null; // Or throw an exception if appropriate.
            }
        }


        // Add a new user
        public bool AddUser(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                _logger.LogError("Invalid username provided.");
                throw new ArgumentException("Username cannot be null or empty.", nameof(username));
            }

            if (_users.Contains(username))
            {
                _logger.LogWarning("User already exists: {Username}", username);
                return false; // Or throw an exception if appropriate.
            }

            _users.Add(username);
            _logger.LogInformation("User added successfully: {Username}", username);
            return true;
        }

        // Remove a user
        public bool RemoveUser(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                _logger.LogError("Invalid username provided.");
                throw new ArgumentException("Username cannot be null or empty.", nameof(username));
            }

            if (!_users.Contains(username))
            {
                _logger.LogWarning("User not found: {Username}", username);
                return false;
            }

            _users.Remove(username);
            _logger.LogInformation("User removed successfully: {Username}", username);
            return true;
        }


        // Alternative `ManageUsers` method demonstrating secure password handling (example only)
        public SecureString? ManageUsers()
        {
            _logger.LogInformation("Managing users with secure password example.");

            try
            {
                SecureString password = new SecureString();
                foreach (char c in "P@$$wOrd")
                {
                    password.AppendChar(c);
                }
                password.MakeReadOnly();
                _logger.LogInformation("Secure password created successfully.");
                return password;
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, "Error creating secure password.");
                return null;
            }
        }
    }
}


// Example usage (in a controller or other component)
// Requires dependency injection setup in your application's startup.
public class UserController
{
    private readonly IUserManager _userManager;
    private readonly ILogger<UserController> _logger;

    public UserController(IUserManager userManager, ILogger<UserController> logger)
    {
        _userManager = userManager;
        _logger = logger;
    }

    public IActionResult GetUsers()
    {
        var users = _userManager.GetUsers();
        return Ok(users);
    }

    public IActionResult GetUser(int index)
    {
        var user = _userManager.GetUser(index);

        if(user == null)
        {
            return NotFound(); // Or appropriate error response
        }

        return Ok(user);
    }

    public IActionResult AddUser(string username)
    {
        try
        {
            if (_userManager.AddUser(username))
            {
                return Ok(); // Or CreatedAtAction
            }
            else
            {
                return Conflict(); // Or appropriate error response
            }
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Invalid username provided");
            return BadRequest(ex.Message);
        }
    }
}


    // In Startup.cs (ConfigureServices method)
    public void ConfigureServices(IServiceCollection services)
    {
        // Add logging
        services.AddLogging(builder =>
        {
            builder.AddConsole(); // Output to the console
            builder.AddDebug();   // Output to the debug window
        });

        // Register IUserManager and UserManager
        services.AddSingleton<IUserManager, UserManager>(); // Or AddScoped or AddTransient depending on lifetime requirements
        services.AddControllers(); // If using an API controller.
    }